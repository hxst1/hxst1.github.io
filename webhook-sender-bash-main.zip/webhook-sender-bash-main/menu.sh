#!/bin/bash

echo -e "Webhook bash sender"
read -p "webhook url: " webhook
read -p "Username bot: " username
read -p "avatar [url]: " avatar
read -p "Titulo: " title
read -p "Texto: " text
read -p "descripcion: " desc
read -p "url: " url
read -p "bucle? [si/no]: " bucle

if [ "$bucle" = "si" ]; then
        while :
        do
        ./discord.sh --webhook-url "${webhook}" --username "${username}" --avatar "${avatar}" --title "${title}" --text "${text}" --tts --description "${desc}" --url "${url}"
        sleep 2s
        done

elif [ "$bucle" = "no" ]; then
        ./discord.sh --webhook-url "${webhook}" --username "${username}" --avatar "${avatar}" --title "${title}" --text "${text}" --description "${desc}" --url "${url}"
fi
